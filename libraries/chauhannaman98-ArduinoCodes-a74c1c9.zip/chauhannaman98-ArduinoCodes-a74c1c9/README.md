# ArduinoCodes

Go to my Hackster page [@Techmirtz](https://www.hackster.io/techmirtz "Hackster - Techmirtz") or search google me as *techmirtz* [here](https://www.google.co.in/search?q=techmirtz "Search Techmirtz on Google")