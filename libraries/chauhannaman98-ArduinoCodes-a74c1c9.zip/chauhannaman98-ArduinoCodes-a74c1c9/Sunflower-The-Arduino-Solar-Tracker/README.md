# Sunflower-The-Arduino-Solar-Tracker

Click **[here](https://www.hackster.io/techmirtz/sunflower-arduino-solar-tracker-bea8b5)** to view full project on hackster.io

## Introduction

'The Sunflower' is an Arduino based solar tracker which will increase the efficiency of the solar panel while charging.
In modern solar tracking systems, the solar panels are fixed on a structure that moves according to the position of the sun. Let us design a solar tracker using two servo motors, a light sensor consisting of four mini photocells and Arduino UNO board.
