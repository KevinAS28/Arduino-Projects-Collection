# Pan Tilt Assenbly

## Here are the pics showing steps for the assembly of the pan tilt.
